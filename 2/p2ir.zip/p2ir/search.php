<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <style>
    html,body{
      height: 100%;
      background: red;

    }



    #form *{
        margin: 10px;
        text-align: center;
        display: flex;
        justify-content: center;
      }
    
    a{
        color:blue;
        font-family: cursive;
        font-weight: bold;
        text-decoration: none;
        font-size:40px;
      }
      .lolo{
        display: flex;
        justify-content: left;
        align-items: center;
        height: 100%;
        color:black;
        font-size:30px;
        font-family:cursive;
        font-weight: bold;

      }
 
    </style>
  </head>
  <body>
<a href="index.html">back</a>
<div class="lolo">

<?php
//SUMMATION

function summationprod($arr1,$arr2)
{
  $sum=0.0;
  foreach ($arr1 as $key => $value) {
    $sum += $value*$arr2[$key];
  }
  return $sum;
}
function summationsqr($arr)
{
  $sum=0.0;
  foreach ($arr as $num) {
    $sum += $num*$num;
  }
  return $sum;
}
$file1 =str_split(preg_replace('/\s/','',file_get_contents
("files/file1.txt", true)));
$file2 =str_split(preg_replace('/\s/','',file_get_contents
("files/file2.txt", true)));
$file3 =str_split(preg_replace('/\s/','',file_get_contents
("files/file3.txt", true)));
  


//INITIALE
$Matrix = array(
  array('A' => 0.0,'B' => 0.0,'C' => 0.0,'D' => 0.0,'E' => 0.0),//file1
  array('A' => 0.0,'B' => 0.0,'C' => 0.0,'D' => 0.0,'E' => 0.0),//file2
  array('A' => 0.0,'B' => 0.0,'C' => 0.0,'D' => 0.0,'E' => 0.0)//file3
);






$df=array('A' => 0.00,'B' => 0.00,'C' => 0.00,'D' => 0.00,'E' => 0.00);
// FRECUENCIES AND DF
foreach ($file1 as $AMR ) {
  $Matrix[0][$AMR] += 1;
  $df[$AMR] += 1;
}
foreach ($file2 as $AMR ) {
  $Matrix[1][$AMR] += 1;
  $df[$AMR] += 1;
}
foreach ($file3 as $AMR ) {
  $Matrix[2][$AMR] += 1;
  $df[$AMR] += 1;
}
//TF
foreach ($Matrix as $key1 => $val) {
  $max = max($val);
  foreach ($val as $key2 => $value) {
    $Matrix[$key1][$key2] = $value/$max;
  }
}
//IDF
$numoffiles=3;
foreach ($df as $key => $value) {
  $df[$key]=log($numoffiles/$value,2);
}
// WEIGHTS = tf*idf
foreach ($Matrix as $key1 => $val) {
  foreach ($val as $key2 => $tf) {
    $Matrix[$key1][$key2] = $tf*$df[$key2];
  }
}

$query = str_split(strtoupper($_GET['query']));
$querymatrix = array('A' => 0.0,'B' => 0.0,'C' => 0.0,'D' => 0.0,'E' => 0.0);
foreach ($query as $value) {
  $querymatrix[$value] += 1;
}
$qMax = max($querymatrix);
foreach ($querymatrix as $key => $value) {
  $querymatrix[$key] = $value/$qMax * $df[$key];
} 
// COSINE SIMILARITY
$querysummationsqr = summationsqr($querymatrix);
$docs = array('d1' => 0,'d2'=>1,'d3'=>2);
foreach ($docs as $key => $value) {
  $docs[$key] = summationprod($Matrix[$value],$querymatrix)/sqrt(summationsqr($Matrix[$value])*$querysummationsqr);
}
arsort($docs);
foreach ($docs as $key => $value) {
  ?>
    <?php echo $key .':' . $value.'<br>' ;?> 
    <?php
}


 ?>
</div>
</body>
</html>
